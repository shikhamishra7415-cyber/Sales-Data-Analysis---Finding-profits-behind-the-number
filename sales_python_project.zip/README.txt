Sales Data Analysis - Python Project
Files included:
- cleaned_sales_data.csv    : cleaned data
- sales_by_region.png       : bar chart of sales by region/state
- sales_by_category.png     : pie chart of sales by category (if category exists)
- monthly_sales_trend.png   : line chart for monthly sales (if dates present)
- discount_vs_profit.png    : scatter plot of discount vs profit
- analysis_script.py        : starter script to run on your own machine with full dataset
- summary.json              : quick numeric summary

How to use:
1. If you have the full 'SampleSuperstore.csv', place it in the same folder and run analysis_script.py
2. Open the PNG files to view charts, or open cleaned_sales_data.csv in Excel/Pandas.

"""
Sales Data Analysis - analysis_script.py
Run this script in a folder containing 'SampleSuperstore.csv' (or it will use sample data).
Generates cleaned_sales_data.csv and plots in the 'sales_python_project' folder.
"""

import pandas as pd
import matplotlib.pyplot as plt

# Load data
csv_path = "SampleSuperstore.csv"
try:
    df = pd.read_csv(csv_path, parse_dates=['Order Date'], encoding='latin1')
    print("Loaded SampleSuperstore.csv")
except FileNotFoundError:
    print("SampleSuperstore.csv not found. Please place the file in the script folder and re-run.")
    raise

# Basic cleaning
df.drop_duplicates(inplace=True)
df = df[~df['Sales'].isnull() & ~df['Profit'].isnull()].reset_index(drop=True)
df['Year'] = pd.to_datetime(df['Order Date']).dt.year
df['Month'] = pd.to_datetime(df['Order Date']).dt.strftime('%b')
df['Profit Margin'] = (df['Profit'] / df['Sales']).round(3)

# Save cleaned
df.to_csv("cleaned_sales_data.csv", index=False)
print("Saved cleaned_sales_data.csv")

# Plots (example)
sales_by_region = df.groupby('Region')['Sales'].sum().sort_values(ascending=False)
ax = sales_by_region.plot(kind='bar', title='Sales by Region')
ax.set_ylabel('Sales')
plt.tight_layout()
plt.savefig("sales_by_region.png")
plt.close()
print("Saved sales_by_region.png")

# Additional plots can be added similarly.
